def FoodLog(data):
	# print(data[1:])
	data = data[1:]
	str1 = ''.join(data)
	str1 = str1.split(",")
	# print(str1[0])
	food = {}
	res = {}
	if str1[0] not in food:
		food[str1[0]] = str1[1:]
		res['Food'] = food
	print("Food:")
	for key,val in res.items():
		for key1,val1 in val.items():
			print(val1[0])
			# print(key1,val1)
			print("- " + val1[1] + ": " + key1)
	# display(res)

def display(res):
	# 	for key,val in res.items():
	# 	for key1,val1 in val.items():
	# 		if val1[0] not in result:
	# 			result[val1[0]] = val1[1]
	# 			# print(val1[0])
	# 		else:
	# 			result[val1[0]] += val1[1]

	# 		# print(key1,val1)
	# 			print("- " + val1[1] + ": " + key1)
	# print(result)

	# result = {}
	# str1 = ""
	# time = ""
	# for key,val in res.items():
	# 	for key1,val1 in val.items():
	# 		time = val1[0]
	# 		# print(val1[0])
	# 		str1 = "- " + val1[1] + ": " + key1
	# 		result.update({time:str1})
	# 		# print(key1,val1)
	# 		# print("- " + val1[1] + ": " + key1)
	# print(result)
	for key,val in res.items():
		for key1,val1 in val.items():
			print(val1[0])
			# print(key1,val1)
			print("- " + val1[1] + ": " + key1)


def WaterLog(data):
	data = data[1:]
	str1 = ''.join(data)
	str1 = str1.split(",")
	# print(str1[0])
	water = {}
	water_res = {}
	if str1[0] not in water:
		water[str1[0]] = str1[1:]
		water_res['Water'] = water
	# print("Water:")
	print("Water:")
	display(water_res)
	# print(water_res)

def WeightLog(data):
	data = data[1:]
	str1 = ''.join(data)
	str1 = str1.split(",")
	# print(str1[0])
	weight = {}
	weight_res = {}
	if str1[0] not in weight:
		weight[str1[0]] = str1[1:]
		weight_res['Weight'] = weight
	
	print("Weight:")
	display(weight_res)

def PhysicalLog(data):
	data = data[1:]
	str1 = ''.join(data)
	str1 = str1.split(",")
	# print(str1[0])
	physical = {}
	phy_res = {}
	if str1[0] not in physical:
		physical[str1[0]] = str1[1:]
		phy_res['PhysicalActivity'] = physical
	print("PhysicalActivity:")
	display(phy_res)

def SleepLog(data):
	data = data[1:]
	str1 = ''.join(data)
	str1 = str1.split(",")
	# print(str1[0])
	sleep = {}
	sleep_res = {}
	if str1[0] not in sleep:
		sleep[str1[0]] = str1[1:]
		sleep_res['Sleep'] = sleep
	# print("Water:")
	print("Sleep:")
	display(sleep_res)

def main():
	lines = int(input())
	for x in range(lines):
		data = input().split(" ")
		if data[0] == "Food":
			FoodLog(data)
		if data[0] == "Water":
			WaterLog(data)
		if data[0] == "PhysicalActivity":
			PhysicalLog(data)
		if data[0] == "Weight":
			WeightLog(data)
		if data[0] == "Sleep":
			SleepLog(data)
		if data[0] == "Summary":
			print("Summary")
			# FoodLog(data)
			# print(WaterLog(data))
			# print(PhysicalLog(data))
			# print(WeightLog(data))
			# print(SleepLog(data))

if __name__ == '__main__':
	main()