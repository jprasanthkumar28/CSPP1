def check_response(data):
    # print(data)
    total_score = 0
    flag = 0
    sid = []
    for item in data:
        # print(item)
        sid.append(int(item[0]))
    sid = set(sid)
    sid = list(sid)
    lst = []

    for value in data:
        # if value[4] != type(int):
        #     print("Invalid Points")
        #     break
        if int(value[0]) in sid:
            # print(value[0])
            if value[2] == value[3]:
                total_score = int(value[4])
                lst.append(int(value[0]))
                lst.append(total_score)
                # print(total_score,value[0])
            else:
                total_score = -(int(value[4]))
                lst.append(int(value[0]))
                lst.append(total_score)
                # print(total_score,value[0])
    print(lst)
    # for i in range(len(lst)):
    #     if lst[i] == lst[i+2]:
    #         print(lst[i], lst[i+1])
    #     if lst[i] in lst:
    #         print(lst[i])
    #     print(lst[i],"=========",i)
    #     if lst[i] == lst[i+1]:
    #         print("HI")
        # print(lst[i])
    print(sid)
    score = 0
    for i in range(len(sid)):
        for item in data:
            if sid[i] == int(item[0]):
                if item[2] == item[3]:
                    score += int(item[4])
    print(int(item[0]), score)
    # for value in lst:
    #     print(value)


def main():
    number = int(input())
    global questions
    questions = []
    for i in range(number):
        questions.append(input().split("|"))
    # print(questions)
    check_response(questions)

if __name__ == '__main__':
    main()