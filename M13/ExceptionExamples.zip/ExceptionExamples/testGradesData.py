

Eric, Grimson, 80
John, Guttag, 100
Ana, Bell, 90
Drew, Houston, 70
Mark, Zuckerberg, 75
Bill, Gates
Deadpool, 25
Baron, von, Richthofen, 65
